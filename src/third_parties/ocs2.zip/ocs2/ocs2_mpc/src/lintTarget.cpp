#include <ocs2_mpc/MPC_BASE.h>
#include <ocs2_mpc/MPC_MRT_Interface.h>
#include <ocs2_mpc/MPC_Settings.h>
#include <ocs2_mpc/MRT_BASE.h>

#include <ocs2_mpc/CommandData.h>
#include <ocs2_mpc/SystemObservation.h>

// dummy target for clang toolchain
int main() {
  return 0;
}
