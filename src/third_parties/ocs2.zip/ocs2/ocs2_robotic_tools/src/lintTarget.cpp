#include <ocs2_robotic_tools/common/AngularVelocityMapping.h>
// #include <ocs2_robotic_tools/common/LoopshapingRobotInterface.h>
#include <ocs2_robotic_tools/common/RobotInterface.h>
#include <ocs2_robotic_tools/common/RotationTransforms.h>

// dummy target for clang toolchain
int main() {
  return 0;
}
