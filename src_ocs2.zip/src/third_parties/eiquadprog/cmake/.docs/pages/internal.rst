Internal commands
*****************

.. setmode:: internal

.. cmake-module:: ../../version.cmake
.. cmake-module:: ../../pkg-config.cmake
.. cmake-module:: ../../header.cmake
.. cmake-module:: ../../cxx-standard.cmake

Doxygen related
===============
.. cmake-module:: ../../doxygen.cmake
